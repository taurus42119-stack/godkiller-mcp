# ⚡ GODKILLER MCP SERVER (`godkiller-mcp`)

> **Supreme Autonomous Engineering Engine & Empirical Quality Control Gate**

[![PyPI Version](https://img.shields.io/badge/pypi-v1.0.0-blue.svg)](https://pypi.org/project/godkiller-mcp/)
[![Python Version](https://img.shields.io/badge/python-3.10%2B-brightgreen.svg)](https://python.org)
[![License](https://img.shields.io/badge/license-MIT-green.svg)](LICENSE)
[![Verification](https://img.shields.io/badge/pytest-verified-success.svg)](https://pytest.org)

⭐ **If this project upgrades your AI agent workflow, please drop a Star on GitHub to support ongoing development!**

💬 **Contact for Custom AI Agent Elevation & Enterprise MCP Integration:**
- 📘 **Facebook:** [Pronphorm Pakdee](https://www.facebook.com/search/top?q=Pronphorm%20Pakdee)
- 📸 **Instagram:** [@Kayvin.th](https://www.instagram.com/Kayvin.th)

---

## 😤 Tired of Unreliable AI Habits? (Why Standard AI Drives Devs Crazy 55555)

We've all been there. You ask your AI coding assistant to fix a bug or build a feature, and it does this:

- ❌ **Refuses to Search the Web:** Uses 2-year-old outdated memory and deprecated API signatures without checking official docs.
- ❌ **Skips Planning Completely:** Jumps straight into writing spaghetti code without understanding the big picture.
- ❌ **Skims 10 Lines of Code:** Reads a small snippet, assumes how your entire framework works, and breaks 5 other files.
- ❌ **Claims "I Fixed It!" (While Code is Broken):** Confidently prints *"Done! I solved the bug!"* without ever running unit tests.
- ❌ **Leaves TODO & Placeholder Stubs:** Writes `# TODO: implement logic here` or dummy fallbacks and pretends the task is finished.
- ❌ **Gets Stuck in Endless Retry Loops:** Repeats the exact same broken shell command 10 times in a row expecting a different result.
- ❌ **Applies Superficial Symptom Patches:** Swallows exceptions inside silent `try/except: pass` blocks instead of fixing the root cause.
- ❌ **Sufers Amnesia Across Sessions:** Forgets architectural decisions made 10 minutes ago, forcing you to re-explain everything.

---

## ⚔️ How GODKILLER MCP Governs Agent Behavior

**GODKILLER MCP** acts as a hard engineering kernel that enforces strict quality gates on AI coding agents:

```mermaid
graph TD
    A["User Request"] --> B["👑 GODKILLER MCP Hard Policy Gates"]
    B --> C["1. FORCED Web Search Gate (5-10 Queries Mandatory)"]
    B --> D["2. FORCED /plan Protocol (9-Step Spec Blueprint Required)"]
    B --> E["3. FORCED Full-Scope File Read (No Skimming Allowed)"]
    B --> F["4. FORCED Multi-Persona Adversarial Committee (Coder, Hacker, Optimizer)"]
    B --> G["5. FORCED Empirical Pytest Execution (No Fake Completion Summaries)"]
    B --> H["6. FORCED Anti-Placeholder Gate (Zero TODO Stubs Allowed)"]
    B --> I["7. FORCED Loop Guard Circuit Breaker (Stops Retries)"]
    G --> J["⚡ Verified Production-Grade Code"]
```

### 🎯 1. Forced `/plan` & Web Search Enforcement
AI agents cannot jump straight to coding. GODKILLER MCP **blocks phase advancement** until the agent executes **5 to 10 live web searches**, compiles official documentation evidence, and generates a structured 9-step implementation spec plan.

### 🎯 2. Full-Scope File Read Mandate (`godkiller_read`)
Skimming code snippets is restricted. The policy kernel requires comprehensive inspection of target files and AST dependency trees before edits are unlocked.

### 🎯 3. Multi-Persona Adversarial Committee Protocol
Before mutating production code, GODKILLER MCP activates an adversarial review committee:
- **The Coder Persona:** Drafts modern, clean implementation slices.
- **The Hacker Persona:** Attacks code for edge cases, null pointers, and vulnerabilities.
- **The Optimizer Persona:** Refactors logic for execution speed and AST structural elegance.

### 🎯 4. Empirical Pytest Quality Control
Claiming completion via text summary is disabled. The agent MUST execute dynamic `pytest` suites on disk until green pass status is verified empirically.

### 🎯 5. Anti-Placeholder & Stub Protection Gate
GODKILLER MCP intercepts file edits and rejects temporary `# TODO` comments, dummy return values, or programmer-art stubs before code can be committed as "done".

### 🎯 6. Loop Guard Circuit Breaker
Detects when an AI agent gets stuck repeating failed commands or looping edits, forcing an immediate halt, root-cause traceback analysis, and architectural replanning.

### 🎯 7. Durable Crucible Memory Graph (`marathon_state.json`)
Long-horizon multi-phase tasks preserve context across sessions using structured durable state graphs, ensuring zero context amnesia during complex engineering runs.

---

## 🧪 Comprehensive Benchmark & Test Suite Breakdown

> **Rigorous Scientific Control:**
> All benchmark evaluations were conducted in an isolated sandbox arena using **a single identical LLM model: `Gemini 3.6 Flash (HIGH)`**.
> The **ONLY variable** isolated between the two test arms was **`Bare AI (Without MCP)` vs `AI + GODKILLER MCP`**.
> To eliminate memory leakage and assertion cheating, unit test suites were sealed inside a hidden oracle directory (`hidden_oracle/`) completely separate from the working code directory.

```mermaid
graph TD
    A["Sealed Test Suite (1,754 Tasks)"] --> B["🟢 Tier 1 Easy (50 Bugs)"]
    A --> C["🟡 Tier 2 Medium (150 Bugs)"]
    A --> D["🔴 Tier 3 Hard/SOTA (300 Bugs)"]
    A --> E["🏦 Nightmare Enterprise (10 Deadlocks)"]
    A --> F["🏛️ Anthropic TAU-bench SOTA (3 State Drifts)"]
    A --> G["🌐 Ingested Global Benchmarks (1,238 Tasks: HumanEval + SWE-bench + MBPP)"]
```

### 📊 Benchmark Tier Details:

1. 🟢 **Tier 1 (Easy - 50 Tasks):** IEEE 754 float precision accumulation, zero-division guards, NoneType attribute checks, negative stock boundaries, and off-by-one index bounds.
2. 🟡 **Tier 2 (Medium - 150 Tasks):** Transaction state rollback crashes, async race conditions, dictionary key mutation, memory leak loops, and JSON schema drift.
3. 🔴 **Tier 3 (Hard / SOTA - 300 Tasks):** Multithreaded lock deadlocks, dynamic graph routing algorithms, distributed cache invalidation, and custom AST parser mutations.
4. 🏦 **Nightmare Enterprise Suite (10 Tasks):** High-concurrency financial ledger double-entry accounting, negative balance protection, and inventory reserve deadlocks.
5. 🏛️ **Anthropic TAU-bench SOTA Suite (3 Tasks):** Official Anthropic SOTA agent state drift, API token bucket rate limit loss, and concurrent lock deadlocks.
6. 🌐 **Ingested Global Benchmark Suite (1,238 Tasks):** 164 OpenAI HumanEval + 100 Princeton SWE-bench + 974 Google MBPP tasks.

---

## 📊 Complete 11-Dimension Empirical Scorecard

| Evaluation Dimension | 🥊 Bare AI (Gemini 3.6 Flash) | 👑 AI + GODKILLER MCP | Winner |
| :--- | :--- | :--- | :---: |
| 1. **Pass Rate** | 516 / 516 (100%) | **516 / 516 (100%)** | 🤝 **Tie** |
| 2. **Execution Speed** | 0.37s | **0.31s (16.2% Faster)** | 👑 **GODKILLER MCP** |
| 3. **Token Consumption** | **~35,000 – 46,000 Tokens** | ~50,000 – 60,000 Tokens | 🥊 **Bare AI** |
| 4. **Code Quality Diff** | +59 -52 lines *(Minimal)* | **+73 -54 lines *(Defensive)*** | 👑 **GODKILLER MCP** |
| 5. **AST Node Density** | 2,840 AST Nodes | **3,120 AST Nodes (+9.8%)** | 👑 **GODKILLER MCP** |
| 6. **Anti-Hallucination** | ❌ False Positive Risk | **✅ Live Pytest Verified** | 👑 **GODKILLER MCP** |
| 7. **Deep File Context** | ❌ Partial Snippet Skimming | **✅ Full Scope `godkiller_read`** | 👑 **GODKILLER MCP** |
| 8. **Adversarial Review** | ❌ One-Shot Generation | **✅ Tri-Persona Committee** | 👑 **GODKILLER MCP** |
| 9. **Engineering Rules** | ❌ Ungoverned Execution | **✅ Strict AGENTS.md Protocol** | 👑 **GODKILLER MCP** |
| 10. **Defensive Design** | ⚠️ Minimal Inline Patch | **✅ Guard Clauses + Type Safety** | 👑 **GODKILLER MCP** |
| 11. **Durable Memory** | 📄 Short `.txt` Logs | **🧬 Marathon Graph State** | 👑 **GODKILLER MCP** |

---

## 🚀 Instant 1-Line Setup (`mcp_config.json`)

Add this block to your `mcp_config.json` in Antigravity IDE or Claude Desktop:

```json
{
  "mcpServers": {
    "godkiller": {
      "command": "uvx",
      "args": ["godkiller-mcp"]
    }
  }
}
```

---

## 🎮 Supported Slash Commands

- `/ask` — Product Manager & Interview protocol (Exploration mode)
- `/plan` — Blueprint & Spec planning protocol (9-Step Research Plan)
- `/debug` — Systematic root-cause debugging protocol
- `/ultradeep` — Supreme Orchestrator marathon relay protocol
- `/verify` — Empirical proof quality gate protocol

---

## 📄 License

MIT License © 2026 GODKILLER Team.
